fetch("http://localhost/phpmyadmin/index.php?route=/database/structure&db=luxhorizon")
    .then(response => response.json())
    .then(data => {
        data.forEach(car => {
            // Külön változók létrehozása
            let car_id = car.car_id;
            let brand_id = car.brand_id;
            let category_id = car.category_id;
            let model = car.model;
            let hp = car.hp;
            let engine = car.engine;
            let top_speed = car.top_speed;
            let gears = car.gears;
            let drive = car.drive;
            let acceleration = car.acceleration;
            let image_url = car.image_url;
            let rent_price = car.rent_price;
            let lap_price_1 = car.lap_price_1;
            let lap_price_3 = car.lap_price_3;
            let lap_price_5 = car.lap_price_5;
            let lap_price_10 = car.lap_price_10;
            let available = car.available;

            console.log(`Autó: ${model}, Teljesítmény: ${hp} LE, Sebesség: ${top_speed} km/h`);
        });
    })
    .catch(error => console.error("Hiba a fetch során:", error));
