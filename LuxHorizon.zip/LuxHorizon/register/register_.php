<?php
session_start();

// Adatbázis kapcsolat beállítása
$servername = "localhost";
$username = "root"; // Alapértelmezett felhasználónév
$password = ""; // Alapértelmezett jelszó
$dbname = "luxhorizon";

// Kapcsolódás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);

// Kapcsolat ellenőrzése
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Regisztráció
if (isset($_POST['signup'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Jelszavak egyezésének ellenőrzése
    if ($password !== $confirm_password) {
        echo "A jelszavak nem egyeznek!";
        exit();
    }

    // Jelszó hashelése
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Felhasználó beszúrása az adatbázisba
    $stmt = $conn->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashed_password);

    if ($stmt->execute()) {
        echo "Sikeres regisztráció!";
    } else {
        echo "Hiba a regisztráció során: " . $stmt->error;
    }

    $stmt->close();
}

// Bejelentkezés
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Felhasználó keresése az adatbázisban
    $stmt = $conn->prepare("SELECT user_id, name, password_hash FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($user_id, $name, $hashed_password);

    if ($stmt->fetch() && password_verify($password, $hashed_password)) {
        // Bejelentkezés sikeres
        $_SESSION['user_id'] = $user_id;
        $_SESSION['user_name'] = $name;
        echo "Sikeres bejelentkezés!";
        // Átirányítás egy másik oldalra (pl. dashboard.php)
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Hibás email vagy jelszó!";
    }

    $stmt->close();
}

$conn->close();
?>