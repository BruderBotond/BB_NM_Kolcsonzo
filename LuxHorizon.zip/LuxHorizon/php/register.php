<?php  
session_start();  

// Adatbázis kapcsolat beállítása  
$servername = "localhost";  
$username = "root"; // Alapértelmezett felhasználónév  
$password = ""; // Alapértelmezett jelszó  
$dbname = "luxhorizon";  

// Kapcsolódás az adatbázishoz  
$conn = new mysqli($servername, $username, $password, $dbname);  

// Kapcsolat ellenőrzése  
if ($conn->connect_error) {  
    die("Connection failed: " . $conn->connect_error);  
}  

// Regisztráció  
if (isset($_POST['signup'])) {  
    $name = $_POST['name'];  
    $password = $_POST['password'];  
    $confirm_password = $_POST['confirm_password'];  

    // Jelszavak egyezésének ellenőrzése  
    if ($password !== $confirm_password) {  
        echo "A jelszavak nem egyeznek!";  
        exit();  
    }  

    // Jelszó hashelése  
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);  

    // Felhasználó beszúrása az adatbázisba  
    $stmt = $conn->prepare("INSERT INTO users (name, password_hash) VALUES (?, ?)");  
    $stmt->bind_param("ss", $name, $hashed_password);  

    if ($stmt->execute()) {  
        // Sikeres regisztráció után átirányítás a login oldalra  
        header("Location: /php/login.php");  
        exit();  
    } else {  
        // Regisztráció sikertelen, marad a regisztrációs oldalon  
        echo "Hiba a regisztráció során: " . $stmt->error;  
    }  

    $stmt->close();  
}  

$conn->close();  
?>  