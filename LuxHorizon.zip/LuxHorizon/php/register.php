<?php  
session_start();  

// Adatbázis kapcsolat beállítása  
$servername = "localhost";  
$username = "root"; // Alapértelmezett felhasználónév  
$password = ""; // Alapértelmezett jelszó  
$dbname = "luxhorizon";  

// Kapcsolódás az adatbázishoz  
$conn = new mysqli($servername, $username, $password, $dbname);  

// Kapcsolat ellenőrzése  
if ($conn->connect_error) {  
    die("Connection failed: " . $conn->connect_error);  
}  

// Regisztráció  
if (isset($_POST['register'])) {  
    $name = $_POST['name'];  
    $email = $_POST['email'];  
    $password = $_POST['password'];  

    // Hibakezelés  
    $errors = [];  

    // Név ellenőrzése  
    if (empty($name)) {  
        $errors[] = "A név megadása kötelező!";  
    }  

    // Email ellenőrzése  
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {  
        $errors[] = "Érvénytelen email cím!";  
    }  

    // Jelszó ellenőrzése (minimum 6 karakter)  
    if (strlen($password) < 6) {  
        $errors[] = "A jelszónak legalább 6 karakter hosszúnak kell lennie!";  
    }  

    // Ha nincs hiba, folytatjuk a regisztrációt  
    if (empty($errors)) {  
        // Ellenőrizzük, hogy az email már foglalt-e  
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");  
        $stmt->bind_param("s", $email);  
        $stmt->execute();  
        $stmt->store_result();  

        if ($stmt->num_rows > 0) {  
            $errors[] = "Ez az email cím már foglalt!";  
        } else {  
            // Jelszó hashelése  
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);  

            // Felhasználó hozzáadása az adatbázishoz  
            $stmt = $conn->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");  
            $stmt->bind_param("sss", $name, $email, $hashed_password);  

            if ($stmt->execute()) {  
                // Regisztráció sikeres, átirányítás a login.php oldalra  
                header("Location: login.php");  
                exit();  
            } else {  
                $errors[] = "Hiba történt a regisztráció során!";  
            }  
        }  

        $stmt->close();  
    }  

    // Hibák visszaadása a sessionben  
    $_SESSION['errors'] = $errors;  
    header("Location: ./php/register.php");  
    exit();  
}  

$conn->close();  
?>  