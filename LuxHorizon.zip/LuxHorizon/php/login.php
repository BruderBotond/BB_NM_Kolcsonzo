<?php  
session_start();  

// Adatbázis kapcsolat beállítása  
$servername = "localhost";  
$username = "root"; // Alapértelmezett felhasználónév  
$password = ""; // Alapértelmezett jelszó  
$dbname = "luxhorizon";  

// Kapcsolódás az adatbázishoz  
$conn = new mysqli($servername, $username, $password, $dbname);  

// Kapcsolat ellenőrzése  
if ($conn->connect_error) {  
    die("Connection failed: " . $conn->connect_error);  
}  

// Bejelentkezés  
if (isset($_POST['login'])) {  
    $email = $_POST['email'];  
    $password = $_POST['password'];  

    // Felhasználó keresése az adatbázisban  
    $stmt = $conn->prepare("SELECT user_id, name, password_hash FROM users WHERE email = ?");  
    $stmt->bind_param("s", $email);  
    $stmt->execute();  
    $stmt->store_result();  
    $stmt->bind_result($user_id, $name, $hashed_password);  

    if ($stmt->fetch() && password_verify($password, $hashed_password)) {  
        // Bejelentkezés sikeres  
        $_SESSION['user_id'] = $user_id;  
        $_SESSION['user_name'] = $name;  
        // Átirányítás a főoldalra  
        header("Location: /index/index.html");  
        exit();  
    } else {  
        // Bejelentkezés sikertelen, marad a login oldalon  
        echo "Hibás email vagy jelszó!";  
    }  

    $stmt->close();  
}  

$conn->close();  
?>  