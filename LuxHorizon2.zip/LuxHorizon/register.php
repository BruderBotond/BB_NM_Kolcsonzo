<?php  
session_start();  
error_reporting(E_ALL);  
ini_set('display_errors', 1);  

$servername = "localhost";  
$username = "root";  
$password = "";  
$dbname = "luxhorizon";  

$conn = new mysqli($servername, $username, $password, $dbname);  

if ($conn->connect_error) {  
    die("Connection failed: " . $conn->connect_error);  
}  

if (isset($_POST['signup'])) {  
    try {  
        // Adatok tisztítása  
        $name = trim($_POST['name']);  
        $email = trim($_POST['email']);  
        $password = $_POST['password'];  
        $confirm_password = $_POST['confirm_password'];  

        // Ellenőrzések  
        if (empty($name) || empty($email) || empty($password)) {  
            throw new Exception("Minden mező kitöltése kötelező!");  
        }  

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {  
            throw new Exception("Érvénytelen email cím!");  
        }  

        if ($password !== $confirm_password) {  
            throw new Exception("A jelszavak nem egyeznek!");  
        }  

        // Email ellenőrzése  
        $check_stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");  
        $check_stmt->bind_param("s", $email);  
        $check_stmt->execute();  
        $check_result = $check_stmt->get_result();  
        
        if ($check_result->num_rows > 0) {  
            $check_stmt->close();  
            throw new Exception("Ez az email cím már regisztrálva van!");  
        }  
        $check_stmt->close();  

        // Jelszó hashelése  
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);  

        // Felhasználó beszúrása  
        $insert_stmt = $conn->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");  
        $insert_stmt->bind_param("sss", $name, $email, $hashed_password);  

        if ($insert_stmt->execute()) {  
            $insert_stmt->close();  
            header("Location: Register.html");  
            exit();  
        } else {  
            throw new Exception("Hiba történt a regisztráció során: " . $conn->error);  
        }  

    } catch (Exception $e) {  
        header("Location: Register.html");  
        exit();  
    }  
}  

$conn->close();  
?>