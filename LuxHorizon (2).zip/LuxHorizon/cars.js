document.addEventListener('DOMContentLoaded', function() {
    // State variables
    let selectedTrack = null;
    let selectedLaps = null;
    const pricePerLap = 150; // Price per lap in dollars
  
    // DOM elements
    const trackOptions = document.querySelectorAll('.track-option');
    const lapOptions = document.querySelectorAll('.lap-option');
    const selectedLapsElement = document.querySelector('.selected-laps');
    const totalPriceElement = document.querySelector('.total-price');
    const cartButton = document.querySelector('.cart-button');
  
    // Track selection
    trackOptions.forEach(option => {
      option.addEventListener('click', function() {
        // Remove selected class from all track options
        trackOptions.forEach(opt => opt.classList.remove('selected'));
        
        // Add selected class to clicked option
        this.classList.add('selected');
        
        // Update selected track
        selectedTrack = this.getAttribute('data-track');
        
        // Update cart button state
        updateCartButtonState();
      });
    });
  
    // Lap selection
    lapOptions.forEach(option => {
      option.addEventListener('click', function() {
        // Remove selected class from all lap options
        lapOptions.forEach(opt => opt.classList.remove('selected'));
        
        // Add selected class to clicked option
        this.classList.add('selected');
        
        // Update selected laps
        selectedLaps = parseInt(this.getAttribute('data-laps'));
        
        // Update laps display
        updateLapsDisplay();
        
        // Update cart button state
        updateCartButtonState();
      });
    });
  
    // Update laps display
    function updateLapsDisplay() {
      if (selectedLaps) {
        selectedLapsElement.textContent = `${selectedLaps} ${selectedLaps === 1 ? 'Lap' : 'Laps'}`;
        totalPriceElement.textContent = `Total: ${calculateTotal()}$`;
      } else {
        selectedLapsElement.textContent = 'Select laps';
        totalPriceElement.textContent = 'Total: 0$';
      }
    }
  
    // Calculate total price
    function calculateTotal() {
      if (selectedLaps === null) return 0;
      return selectedLaps * pricePerLap;
    }
  
    // Update cart button state
    function updateCartButtonState() {
      if (selectedTrack && selectedLaps) {
        cartButton.disabled = false;
      } else {
        cartButton.disabled = true;
      }
    }
  
    // Add to cart button click
    cartButton.addEventListener('click', function() {
      if (selectedTrack && selectedLaps) {
        alert(`Added to cart: ${selectedLaps} laps at ${selectedTrack} track for $${calculateTotal()}`);
      }
    });
  });